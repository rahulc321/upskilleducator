<footer class="footer text-right">
    © {{ date('Y') }}. All rights reserved.
</footer>
